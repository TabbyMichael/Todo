import React from 'react';
import Header from './components/layout/Header';
import Calendar from './components/calendar/Calendar';
import TodoList from './components/todos/TodoList';
import AnalyticsCard from './components/analytics/AnalyticsCard';
import TimeTrackingChart from './components/dashboard/TimeTrackingChart';

const mockAnalytics = {
  positiveHabits: 5,
  percentageIncrease: 58.2
};

const mockTimeTracking = Array.from({ length: 7 }, (_, i) => ({
  date: new Date(Date.now() - (6 - i) * 24 * 60 * 60 * 1000).toISOString(),
  completed: Math.floor(Math.random() * 10),
  total: 10,
  timeSpent: Math.floor(Math.random() * 180)
}));

function App() {
  return (
    <div className="min-h-screen bg-[#F5F7FA]">
      <Header />
      
      <main className="container mx-auto p-6">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold mb-1">Happy Tuesday 👋</h1>
            <p className="text-gray-500">30 Dec 2023, 10:03 am</p>
          </div>
          <button className="bg-[#6C5CE7] text-white px-6 py-3 rounded-xl font-medium hover:bg-[#6C5CE7]/90 transition-colors">
            + New Habits
          </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <Calendar />
            <TimeTrackingChart data={mockTimeTracking} />
          </div>

          <div className="space-y-6">
            <TodoList />
            <AnalyticsCard data={mockAnalytics} />
          </div>
        </div>
      </main>
    </div>
  );
}

export default App;