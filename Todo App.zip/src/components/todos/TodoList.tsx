import React from 'react';
import { Book, ShoppingCart, Salad, Waves } from 'lucide-react';
import type { Habit } from '../../types/habit';

const TodoList = () => {
  const todos: Habit[] = [
    {
      id: '1',
      title: 'Study',
      time: '10:30 am',
      location: 'K-Cafe',
      icon: 'Book'
    },
    {
      id: '2',
      title: 'Groceries',
      time: '02:00 pm',
      location: 'Hayday Market',
      icon: 'ShoppingCart'
    },
    {
      id: '3',
      title: 'Eat Healthy Food',
      time: '08:30 am',
      location: 'Home',
      icon: 'Salad',
      isCompleted: true
    },
    {
      id: '4',
      title: 'Swimming',
      time: '09:00 am',
      location: 'Gym Pool',
      icon: 'Waves',
      isCompleted: true
    }
  ];

  const getIcon = (iconName: string) => {
    const icons = {
      Book: <Book />,
      ShoppingCart: <ShoppingCart />,
      Salad: <Salad />,
      Waves: <Waves />
    };
    return icons[iconName as keyof typeof icons];
  };

  return (
    <div className="bg-white rounded-xl p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-lg font-semibold">Today's Todos</h2>
        <button className="text-sm text-gray-500">View Details</button>
      </div>
      
      <div className="space-y-4">
        {todos.map((todo) => (
          <div
            key={todo.id}
            className={`flex items-center gap-4 p-3 rounded-lg ${
              todo.isCompleted ? 'bg-gray-50' : ''
            }`}
          >
            <div className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center">
              {getIcon(todo.icon || 'Book')}
            </div>
            <div className="flex-1">
              <h3 className={`font-medium ${
                todo.isCompleted ? 'line-through text-gray-400' : ''
              }`}>
                {todo.title}
              </h3>
              <div className="flex items-center gap-2 text-sm text-gray-500">
                <span>{todo.time}</span>
                <span>•</span>
                <span>{todo.location}</span>
              </div>
            </div>
            {todo.isCompleted && (
              <div className="w-6 h-6 rounded-full bg-green-100 flex items-center justify-center">
                <span className="text-green-500">✓</span>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

export default TodoList;