import React from 'react';
import { Search, Sun, Moon, Bell, Settings } from 'lucide-react';

const Header = () => {
  const currentTime = new Date();
  const formattedTime = currentTime.toLocaleTimeString('en-US', { 
    hour: '2-digit', 
    minute: '2-digit',
    hour12: true 
  });
  const formattedDate = currentTime.toLocaleDateString('en-US', { 
    day: 'numeric',
    month: 'long',
    year: 'numeric'
  });

  return (
    <div className="flex items-center justify-between p-4">
      <div className="flex items-center gap-4">
        <button className="w-8 h-8 flex items-center justify-center text-gray-400">
          ‹
        </button>
        <span className="text-sm text-gray-500">Dashboard | Schedule</span>
        <Search className="w-5 h-5 text-gray-400" />
      </div>
      
      <div className="flex items-center gap-4">
        <button className="w-8 h-8 flex items-center justify-center">
          <Bell className="w-5 h-5 text-gray-600" />
        </button>
        <button className="w-8 h-8 flex items-center justify-center">
          <Moon className="w-5 h-5 text-gray-600" />
        </button>
        <button className="w-8 h-8 flex items-center justify-center">
          <Settings className="w-5 h-5 text-gray-600" />
        </button>
        <img
          src="https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=32&h=32&fit=crop&crop=faces"
          alt="Profile"
          className="w-8 h-8 rounded-full"
        />
      </div>
    </div>
  );
}

export default Header;